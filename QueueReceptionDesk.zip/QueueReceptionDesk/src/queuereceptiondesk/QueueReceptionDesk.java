package queuereceptiondesk;

import java.io.File;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class QueueReceptionDesk extends JFrame {

    String details;
    String disp = " ";
    TextHandler handler1 = null;
    TextHandler handler2 = null;
    TextHandler handler3 = null;
    TextHandler handler4 = null;
    TextHandler handler5 = null;
    TextHandler handler6 = null;
    TextHandler handler7 = null;

    File outFile1;

    public QueueReceptionDesk() {
        setLayout(new GridLayout(17, 5));
        setTitle("QUEUE APP");

        setSize(420, 500);
        setLocation(200, 100);

        JLabel NewCustomer = new JLabel("New Customer");
        JLabel Services = new JLabel("Services");
        JRadioButton Housing = new JRadioButton("Housing");
        JRadioButton Benefits = new JRadioButton("Benefits");
        JRadioButton CouncilTax = new JRadioButton("Council Tax");
        JRadioButton FlyTipping = new JRadioButton("Fly-tipping");
        JRadioButton MissedBin = new JRadioButton("Missed Bin");

        ButtonGroup group = new ButtonGroup();
        group.add(Housing);
        group.add(Benefits);
        group.add(CouncilTax);
        group.add(FlyTipping);
        group.add(MissedBin);

        JButton Citizen = new JButton("Citizen");
        JButton Organization = new JButton("Organization");
        JButton Anonymous = new JButton("Anonymous");

        JLabel Title = new JLabel("Title");
        JComboBox title1 = new JComboBox(new String[]{"Mr", "Ms", "Mrs", "Miss"});
        JLabel FirstName = new JLabel("First Name");
        JTextField firstname1 = new JTextField(20);
        JLabel LastName = new JLabel("Last Name");
        JTextField lastname1 = new JTextField(20);

        JButton Submit = new JButton("Submit");

        add(NewCustomer);
        add(Services);

        add(Housing);
        add(Benefits);
        add(CouncilTax);
        add(FlyTipping);
        add(MissedBin);

        add(Citizen);
        add(Organization);
        add(Anonymous);

        add(Title);
        add(title1);
        add(FirstName);
        add(firstname1);
        add(LastName);
        add(lastname1);

        add(Submit);

        setVisible(true);

        this.outFile1 = new File("Queue.txt");

        handler1 = new TextHandler();
        firstname1.addActionListener(handler1);
        handler2 = new TextHandler();
        lastname1.addActionListener(handler2);

        Housing.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                writeToFile1("Service: Housing \t");
            }
        });

        Benefits.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                writeToFile1("Service: Benefits \t");
            }
        });
        CouncilTax.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                writeToFile1("Service: Council Tax \t");
            }
        });
        FlyTipping.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                writeToFile1("Service: Fly-tipping \t");
            }
        });
        MissedBin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                writeToFile1("Service: Missed Bin \t");
            }
        });

        //
        Citizen.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                writeToFile1("Type: Citizen \t");
            }
        });

        Organization.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                writeToFile1("Type: Organization \t");
            }
        });

        Anonymous.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                writeToFile1("Type: Anonymous \t");
            }
        });

     
        Submit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                
                
                title1.getSelectedItem();
                String value = (String) title1.getSelectedItem();

                String str1 = firstname1.getText();
                firstname1.requestFocusInWindow();
                String str2 = lastname1.getText();
                lastname1.requestFocusInWindow();

                writeToFile1(value + " " + str1 + " " + str2 + " ");
                writeToFile1("" + new java.util.Date());
                writeToFile1("______________________________");

                firstname1.setText("");
                lastname1.setText("");
                group.clearSelection();
            }
        });

    }

    BufferedWriter out;

    public void writeToFile1(String s) {
        try {
            out = new BufferedWriter(new FileWriter("Queue.txt", true));
            out.write(s);
            out.newLine();
            out.close();
        } catch (IOException e) {
            System.out.println("There was an error" + e);

        }
    }

    public static void main(String[] args) {
        QueueReceptionDesk code = new QueueReceptionDesk();
        code.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }

    private class TextHandler implements ActionListener {

        public void actionPerformed(ActionEvent e) {
            disp = e.getActionCommand();
            System.out.println(disp);

        }
    }

}
